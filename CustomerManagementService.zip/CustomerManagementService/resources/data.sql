INSERT INTO restaurants(budget,cuisine,location,name,rating) VALUES(966,'Soprole','rr nagar','Dominos',4.5);
INSERT INTO restaurants(budget,cuisine,location,name,rating) VALUES(967,'italian','mg road','Aura',4.1);
INSERT INTO restaurants(budget,cuisine,location,name,rating) VALUES(968,'indian','kormangala','Re',4.9);