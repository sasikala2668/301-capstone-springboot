package com.CustomerManagementService.Dto;

import com.CustomerManagementService.Entity.CustomerEntity;

import lombok.Data;

@Data
public class CustomerDto {

	private long id;
	private String name;
	private String phone;
	private String place;
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	public String getPlace() {
		return place;
	}
	public void setPlace(String place) {
		this.place = place;
	}
	
	
}
