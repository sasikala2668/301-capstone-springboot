package com.CustomerManagementService.Controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.CustomerManagementService.Dto.CustomerDto;
import com.CustomerManagementService.Entity.CustomerEntity;
import com.CustomerManagementService.Exception.CustomerException;
import com.CustomerManagementService.Service.CustomerService;




@RestController
@RequestMapping("/Customer")
public class CustomerController {
	@Autowired CustomerService customerService;
	private static final Logger logger = LoggerFactory.getLogger(CustomerController.class);
	
	@PostMapping("/AddUser")
	public ResponseEntity<String> AddUser(@RequestBody CustomerDto customerDto)
	{
		logger.debug("In AddUser method, calling the service");
		customerService.saveUser(customerDto);
		logger.debug("User added Successfully");
		return ResponseEntity
				.status(HttpStatus.OK)
				.body("Customer Added successfully");
		
	}
	
	
	@PutMapping("/update/{id}")
	public ResponseEntity<CustomerEntity> updateCustomer(@PathVariable long id, @RequestBody CustomerDto customerDto) throws CustomerException{
		logger.debug(" In updateCustomer method, calling service");
		
		return new ResponseEntity<CustomerEntity>(customerService.updateCustomer(id,customerDto),HttpStatus.OK);
		
	}
	
	@PutMapping("/deactivate/{name}")
	public ResponseEntity<CustomerEntity> deactivateByName(@PathVariable String name) throws CustomerException
	{
		logger.debug("user deactivating By Name Successfully");
		return new ResponseEntity<CustomerEntity>(customerService.deactivate(name),HttpStatus.OK);
	}
	
	@GetMapping("/getById/{id}")
	public CustomerEntity getById(@PathVariable long id)
	{
		return customerService.getById(id);
	}
	
	
}
