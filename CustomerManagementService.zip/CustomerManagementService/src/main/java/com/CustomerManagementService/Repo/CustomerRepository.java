package com.CustomerManagementService.Repo;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.CustomerManagementService.Entity.CustomerEntity;

@Repository
public interface CustomerRepository extends JpaRepository<CustomerEntity ,Long>{

	Optional<CustomerEntity> findById(long id);

	Optional<CustomerEntity> findByName(String name);

	CustomerEntity getById(long id);

}
