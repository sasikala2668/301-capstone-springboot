package com.CustomerManagementService.Service;

import org.springframework.http.HttpStatus;

import com.CustomerManagementService.Dto.CustomerDto;
import com.CustomerManagementService.Entity.CustomerEntity;
import com.CustomerManagementService.Exception.CustomerException;

public interface CustomerService {

	CustomerEntity saveUser(CustomerDto customerDto);

	CustomerEntity updateCustomer(long id, CustomerDto customerDto) throws CustomerException;

	CustomerEntity deactivate(String name) throws CustomerException;

	CustomerEntity getById(long id);

	

	

}
