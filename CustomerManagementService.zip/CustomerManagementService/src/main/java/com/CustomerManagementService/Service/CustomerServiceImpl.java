package com.CustomerManagementService.Service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CachePut;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.stereotype.Service;

import com.CustomerManagementService.Dto.CustomerDto;
import com.CustomerManagementService.Entity.CustomerEntity;
import com.CustomerManagementService.Exception.CustomerException;
import com.CustomerManagementService.Repo.CustomerRepository;

@Service
@RefreshScope
public class CustomerServiceImpl implements CustomerService{

	@Autowired CustomerRepository customerRepo;
	@Override
	public CustomerEntity saveUser(CustomerDto customerDto) {
		CustomerEntity entity=new CustomerEntity(customerDto.getName(),customerDto.getPhone(),customerDto.getPlace(),"CREATED");
		CustomerEntity customer=customerRepo.save(entity);
		return customer;
	}
	
	

	@Override
	//@CachePut(cacheNames="customers", key="#customerDto.id")
	public CustomerEntity updateCustomer(long id, CustomerDto customerDto) throws CustomerException {
		CustomerEntity existCustomer=customerRepo.findById(id).orElseThrow(
				() -> new CustomerException("Customer Id not found"));
		// existCustomer=new CustomerEntity(customerDto.getName(),customerDto.getPhone(),customerDto.getPlace(),"UPDATED");
		existCustomer.setName(customerDto.getName());
		existCustomer.setPhone(customerDto.getPhone());
		existCustomer.setPlace(customerDto.getPlace());
		existCustomer.setStatus("UPDATED");
		
		customerRepo.save(existCustomer);
		return existCustomer;
	}



	@Override
	public CustomerEntity deactivate(String name) throws CustomerException{
		CustomerEntity DeactivateCustomer=customerRepo.findByName(name).orElseThrow(
				() -> new CustomerException("Customer not not found"));
		
		DeactivateCustomer.setStatus("Deactivate");
		customerRepo.save(DeactivateCustomer);
		
		return DeactivateCustomer;
	}



	@Override
	@Cacheable(cacheNames="customers", key="#id")
	public CustomerEntity getById(long id) {
		
		return customerRepo.getById(id);
	}

}
