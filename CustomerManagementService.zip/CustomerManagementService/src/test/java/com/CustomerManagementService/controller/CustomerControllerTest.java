package com.CustomerManagementService.controller;


import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyDouble;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.Arrays;
import java.util.Date;
import java.util.List;

import org.junit.Before;
import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.RequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import com.CustomerManagementService.Controller.CustomerController;
import com.CustomerManagementService.Dto.CustomerDto;
import com.CustomerManagementService.Entity.CustomerEntity;
import com.CustomerManagementService.Service.CustomerService;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;

@RunWith(SpringRunner.class)
@WebMvcTest(value=CustomerController.class)
public class CustomerControllerTest {

	//@MockBean will create dummy object for customerService
	@MockBean private CustomerService customerService;
	@Autowired
	private ObjectMapper objectMapper;
	@Autowired
	private MockMvc mockMvc;
	String jwt="";
	
	private static final long EXPIRATIONTIME = 900000;
	@Before
	public void setup() {
		jwt = "Bearer "+Jwts.builder().setSubject("user").claim("roles", "user").setIssuedAt(new Date())
				.signWith(SignatureAlgorithm.HS256, "secretkey").setExpiration(new Date(System.currentTimeMillis() + EXPIRATIONTIME)).compact();
	}
	
	@Test
	public void testAddCustomer() throws Exception {
		CustomerDto customerDto =new CustomerDto();
		customerDto.setId(1);
		customerDto.setName("sasi1");
		customerDto.setPhone("123456");
		customerDto.setPlace("ATP");
		
		when(customerService.saveUser(any(CustomerDto.class))).thenReturn(new CustomerEntity());
		RequestBuilder request=MockMvcRequestBuilders.post(
				"/AddUser")
				.contentType(MediaType.APPLICATION_JSON)
				.content(objectMapper.writeValueAsString((customerDto)))
				.header(HttpHeaders.AUTHORIZATION,
						jwt);
		mockMvc.perform(request)
		.andExpect(status().is(200))
		.andExpect(content().string("Customer Added successfully"))
		.andReturn();
		
		
	}
	//@Test
	/*public void getByyUserId() {
		List<CustomerEntity> customer=Arrays.asList(new CustomerEntity("Sasi","234","ATP")
				,new CustomerEntity("Sasikala","12345","Bangalore"));
		
		CustomerDto customerDto=new CustomerDto();
		when(customerService.getById(any(String.class),any(String.class),anyInt(),anyInt())).thenReturn(customerDto);
	}*/
	
}
