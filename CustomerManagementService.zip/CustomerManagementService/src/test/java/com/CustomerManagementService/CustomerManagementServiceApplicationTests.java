package com.CustomerManagementService;

import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.CustomerManagementService.Entity.CustomerEntity;
import com.CustomerManagementService.Repo.CustomerRepository;

@SpringBootTest
class CustomerManagementServiceApplicationTests {

	@Autowired CustomerRepository customerRepo;
	
	
	
	@Test
	public void testAddUser() {
		CustomerEntity entity=new CustomerEntity();
		//entity.setId(4);
		entity.setName("name4");
		entity.setPhone("1234445");
		entity.setPlace("KLD");
		entity.setStatus("CREATED");
		customerRepo.save(entity);
		assertNotNull(customerRepo.findByName("name4").get());
	}
	
	@Test
	public void testdeactivate() {
		CustomerEntity entity=customerRepo.findByName("name4").get();
		entity.setStatus("deactivate");
		customerRepo.save(entity);
		assertNotEquals("CREATED",customerRepo.findByName("name4").get().getStatus());
	}
	
	@Test
	public void testUpdate() {
		CustomerEntity entity=customerRepo.findById(1).get();
		entity.setName("sasikala");
		entity.setPhone("123456789");
		entity.setPlace("Anantapur");
		entity.setStatus("UPDATED");
		customerRepo.save(entity);
		//assertNotEquals("CREATED",customerRepo.findById(1).get().getStatus());
	}
	

}
