package com.cloudgateway.cloudgateway;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import reactor.core.publisher.Mono;

@RestController
public class FallbackController {
	
	@RequestMapping("/restaurantFallback")
	public Mono<String> restaurantServiceFallback(){
		return Mono.just("Restaurant service taking too long to respond or is down. Please try again later");
	}
	
	@RequestMapping("/orderFallback")
	public Mono<String> orderServiceFallback(){
		return Mono.just("Order service taking too long to respond or is down. Please try again later");
	}
	
	@RequestMapping("/customerFallback")
	public Mono<String> customerFallback(){
		return Mono.just("Customer service taking too long to respond or is down. Please try again later");
	}
	
	@RequestMapping("/reviewFallback")
	public Mono<String> reviewFallback(){
		return Mono.just("Review service taking too long to respond or is down. Please try again later");
	}

}
