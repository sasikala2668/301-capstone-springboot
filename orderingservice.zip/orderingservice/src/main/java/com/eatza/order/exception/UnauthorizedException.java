package com.eatza.order.exception;

public class UnauthorizedException extends Exception {
	
	
	public UnauthorizedException() {
		super();
	}
	
	public UnauthorizedException(String msg) {
		super(msg);
	}

}
