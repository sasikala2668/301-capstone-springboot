package com.reviewService;

import org.junit.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ReviewserviceApplicationTests {

	@Test
	void contextLoads() {
	}

}
