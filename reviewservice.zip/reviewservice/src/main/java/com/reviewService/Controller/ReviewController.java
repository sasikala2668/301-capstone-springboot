package com.reviewService.Controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;



import com.reviewService.Dto.ReviewRequestDto;
import com.reviewService.Exception.ReviewException;
import com.reviewService.Model.Review;
import com.reviewService.Service.ReviewService;

@RestController
@RequestMapping("/Review")
public class ReviewController {
	
	
	
	@Autowired ReviewService reviewService;
	private static final Logger logger = LoggerFactory.getLogger(ReviewController.class);

	
	/*@PostMapping("/AddReview")
	public Review AddReview(@RequestHeader String authorization,@RequestBody ReviewRequestDto reviewRequestDto)
	{
		logger.debug("in method to AddReview");
		return reviewService.saveUser(reviewRequestDto);
	}*/
	
	/*@GetMapping("/{reviewId}")
    public ResponseTemplateVO getByreviewId(@RequestHeader String authorization,@PathVariable("reviewId") Long reviewId) {
		logger.debug("in method to getUser");
        return reviewService.getByreviewId(reviewId);
    }*/
	
	@PutMapping("/update/{reviewId}")
	public Review updateByReviewId(@RequestHeader String authorization,@PathVariable Long reviewId,@RequestBody ReviewRequestDto reviewRequestDto ) throws ReviewException {
		return reviewService.updateByReviewId(reviewId,reviewRequestDto);
	}
	@PostMapping("/reviews")
	public Review addReview(@RequestBody Review review) {
		return reviewService.saveReview(review);
	}
	
	@GetMapping("/get")
	public List<Review> getReviews(){
		return reviewService.getReviews(); 
	}
	
    
	
}
