package com.reviewService.Service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Service;
import org.springframework.web.client.ResourceAccessException;
import org.springframework.web.client.RestTemplate;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;


import com.reviewService.Dto.ReviewFetchDto;
import com.reviewService.Dto.ReviewRequestDto;
import com.reviewService.Exception.ReviewException;

import com.reviewService.Model.Review;
import com.reviewService.Repository.ReviewRepository;

import lombok.Value;
@Service
public class ReviewServiceImpl implements ReviewService{

	@Autowired ReviewRepository reviewRepository;
	
	
	
	
	
	
	//private String restaurantServicenameUrl= "http://localhost:8085/Restautrant/restaurant/";
	
	//@Autowired RestTemplate restTemplate;

	/*@Override
	public Review saveUser(ReviewRequestDto reviewRequestDto)  {
		
		Review review=new Review(reviewRequestDto.getRestaurantId(),reviewRequestDto.getReview(),
				reviewRequestDto.getRating(),"CREATED");
		return reviewRepository.save(review);
	}*/

	/*@Override
	  public ResponseTemplateVO getByreviewId(Long reviewId) {
       
        ResponseTemplateVO vo = new ResponseTemplateVO();
        Review review = reviewRepository.findByReviewId(reviewId);

        Restaurant restaurant =
                restTemplate.getForObject("http://localhost:8080/Restaurant/" + review.getRestaurantId()
                        ,Restaurant.class);

        vo.setReview(review);
        vo.setResturant(restaurant);

        return  vo;
    }*/
	
@Autowired KafkaTemplate<String,Object> kafkaTemplate;
	
	//@Value("${review.topic.name}")
	private String topicName="review-topic";
	
	ObjectMapper om=new ObjectMapper();

	@Override
	public Review updateByReviewId(Long reviewId, ReviewRequestDto reviewRequestDto) throws ReviewException {
		Review review=reviewRepository.findById(reviewId).orElseThrow(
				() -> new ReviewException("Customer Id not found"));
		// existCustomer=new CustomerEntity(customerDto.getName(),customerDto.getPhone(),customerDto.getPlace(),"UPDATED");
		review.setRestaurantId(reviewRequestDto.getRestaurantId());
		review.setReview(reviewRequestDto.getReview());
		review.setRating(reviewRequestDto.getRating());
		review.setStatus("UPDATED");
		
		reviewRepository.save(review);
		return review;
	}
	
	@Override
	public Review saveReview(Review review) {
		
		review=reviewRepository.save(review);
		review.setStatus("CREATED");
		String reviewStr=null;
		//String reviewStr;
		try {
			reviewStr = om.writeValueAsString(review);
			//kafkaTemplate.send(topicName,reviewStr);
			kafkaTemplate.send(topicName,reviewStr);
		} catch (JsonProcessingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return review;
	}
	@Override
	public List<Review> getReviews(){
		List<Review> review=reviewRepository.findAll();
		return review;
	}


	

	
	
	
		
}
