package com.reviewService.Service;

import java.util.List;


import com.reviewService.Dto.ReviewRequestDto;
import com.reviewService.Exception.ReviewException;
import com.reviewService.Model.Review;

public interface ReviewService {

	//Review addReview(ReviewRequestDto reviewRequestDto) throws ReviewException;

	//Review saveUser(ReviewRequestDto reviewRequestDto);

	//ResponseTemplateVO getByreviewId(Long reviewId);

	Review updateByReviewId(Long reviewId, ReviewRequestDto reviewRequestDto) throws ReviewException;

	Review saveReview(Review review);

	List<Review> getReviews();

	

}
