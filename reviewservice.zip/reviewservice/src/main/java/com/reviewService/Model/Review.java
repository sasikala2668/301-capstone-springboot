package com.reviewService.Model;

import java.time.LocalDateTime;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Table(name="reviews1")
@Getter @Setter 
public class Review {
	
	@Id
	@GeneratedValue(strategy= GenerationType.IDENTITY)
	private Long reviewId;
	private Long restaurantId;
	private String review;
	private double rating;
	private String status;
	
	public Review() {
		super();
	}
	public Long getReviewId() {
		return reviewId;
	}
	public void setReviewId(Long reviewId) {
		this.reviewId = reviewId;
	}
	public Long getRestaurantId() {
		return restaurantId;
	}
	public void setRestaurantId(Long restaurantId) {
		this.restaurantId = restaurantId;
	}
	public String getReview() {
		return review;
	}
	public void setReview(String review) {
		this.review = review;
	}
	public double getRating() {
		return rating;
	}
	public void setRating(double rating) {
		this.rating = rating;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public Review(Long restaurantId, String review, double rating, String status) {
		super();
		this.restaurantId = restaurantId;
		this.review = review;
		this.rating = rating;
		this.status = status;
	}
	
	

}
